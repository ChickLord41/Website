If an unauthorization error comes please restart the program 
- By ChickLord41