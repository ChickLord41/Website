# Password-Manager  

A Password Manager built in python to safely store and access your passwords  

Features:  
Encrypted Saving of Passwords  
Ability to generate passwords  
Check if password is strong  
Backup passwords  

Usage:  
Type in a master password. This will be your key which will be used to encrypt and decrypt passwords.(Do not forget your master password without it you wont be able to access your passwords)  

Then you can add passwords and usernames by typing in their corresponding fields and clicking add/update. This will add a password if the username is not added before and will update a password if the username exist. You can also type in the account name and click delete to remove it. Click get password after typing in the username to get its password.   

In the accounts section you will have a list of accounts which you saved.  

In the tools section you can generate a strong password.  

In the settings tab you can export backup. In which you will add an export password. This will save all your encrypted passwords and usernames in a bak file which can then be used to import backup which will require the export password you set initially and will import the passwords. 

You can also change your master password. You just need to type in your master password then the new one which you want to set.  
