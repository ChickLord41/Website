import tkinter as tk
from tkinter import filedialog, messagebox
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
import base64
import os

# Constants
SALT_SIZE = 16
ITERATIONS = 100_000

# Derive a Fernet-compatible key from password + salt
def derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=ITERATIONS,
    )
    key = kdf.derive(password.encode())
    return base64.urlsafe_b64encode(key)

def get_decrypted_filename(file_path):
    if file_path.endswith(".encrypted"):
        base = file_path[:-10]
    else:
        base = file_path
    name, ext = os.path.splitext(base)
    return f"{name}_decrypted{ext}"

def encrypt_file(file_path, password):
    try:
        with open(file_path, "rb") as f:
            data = f.read()

        salt = os.urandom(SALT_SIZE)
        key = derive_key(password, salt)
        fernet = Fernet(key)
        encrypted = fernet.encrypt(data)

        with open(file_path + ".encrypted", "wb") as f:
            f.write(salt + encrypted)  # prepend salt to encrypted data

        if delete_original_var.get():
            os.remove(file_path)

        return f"Encrypted: {file_path}"
    except Exception as e:
        return f"Encryption failed for {file_path}: {str(e)}"

def decrypt_file(file_path, password):
    try:
        with open(file_path, "rb") as f:
            data = f.read()

        salt = data[:SALT_SIZE]
        encrypted_data = data[SALT_SIZE:]
        key = derive_key(password, salt)
        fernet = Fernet(key)
        decrypted = fernet.decrypt(encrypted_data)

        output_path = get_decrypted_filename(file_path)
        with open(output_path, "wb") as f:
            f.write(decrypted)

        return f"Decrypted: {file_path}"
    except Exception as e:
        return f"Decryption failed for {file_path}: {str(e)}"

def process_folder(folder_path, action, password):
    results = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            if action == "encrypt":
                if not file_path.endswith(".encrypted"):
                    results.append(encrypt_file(file_path, password))
            elif action == "decrypt":
                if file_path.endswith(".encrypted"):
                    results.append(decrypt_file(file_path, password))
    return results

def browse_path():
    if path_mode.get() == "file":
        selected_path = filedialog.askopenfilename()
    else:
        selected_path = filedialog.askdirectory()
    if selected_path:
        path_entry.delete(0, tk.END)
        path_entry.insert(0, selected_path)

def perform_action():
    selected_path = path_entry.get()
    password = password_entry.get()

    if not selected_path or not password:
        messagebox.showerror("Error", "Please select a file/folder and enter a password.")
        return

    action = mode.get()
    results = []

    if path_mode.get() == "file":
        if action == "encrypt":
            results.append(encrypt_file(selected_path, password))
        else:
            results.append(decrypt_file(selected_path, password))
    else:
        results = process_folder(selected_path, action, password)

    result_msg = "\n".join(results)
    messagebox.showinfo("Result", result_msg[:2000])  # Limit to avoid overflow

# GUI setup
root = tk.Tk()
root.title("Password-Based File Encryptor")

# GUI variables (must be declared after root)
delete_original_var = tk.BooleanVar()
path_mode = tk.StringVar(value="file")
mode = tk.StringVar(value="encrypt")

# File/Folder radio buttons
tk.Radiobutton(root, text="File", variable=path_mode, value="file").grid(row=0, column=0, sticky="w", padx=10)
tk.Radiobutton(root, text="Folder", variable=path_mode, value="folder").grid(row=0, column=1, sticky="w")

# Path entry
tk.Label(root, text="Select:").grid(row=1, column=0, padx=10, pady=10)
path_entry = tk.Entry(root, width=50)
path_entry.grid(row=1, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_path).grid(row=1, column=2, padx=10, pady=10)

# Password entry
tk.Label(root, text="Password:").grid(row=2, column=0, padx=10)
password_entry = tk.Entry(root, width=50, show="*")
password_entry.grid(row=2, column=1, padx=10, pady=10)

# Encrypt/Decrypt mode
tk.Radiobutton(root, text="Encrypt", variable=mode, value="encrypt").grid(row=3, column=1, sticky="w", padx=10)
tk.Radiobutton(root, text="Decrypt", variable=mode, value="decrypt").grid(row=3, column=1, sticky="e", padx=10)

# Delete original checkbox
tk.Checkbutton(root, text="Delete original file(s) after encrypting", variable=delete_original_var).grid(row=4, column=1)

# Start button
tk.Button(root, text="Start", command=perform_action).grid(row=5, column=1, pady=20)

root.mainloop()
